﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management.Automation.Runspaces;
using System.Management.Automation;
using System.Collections.ObjectModel;
using Microsoft.PowerShell.Commands;
using Microsoft.PowerShell;
namespace PSBOX
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        
        private void runButton_Click(object sender, EventArgs e)
        {
            txtOutput.Clear();
            using (PowerShell powerShell = PowerShell.Create())
            {
                powerShell.AddScript(txtInput.Text);
                powerShell.AddCommand("Out-String");
                Collection<PSObject> PSOutput = powerShell.Invoke();
                StringBuilder stringBuilder = new StringBuilder();
                foreach (PSObject pSObject in PSOutput)
                    stringBuilder.AppendLine(pSObject.ToString());
                txtOutput.Text = stringBuilder.ToString();
            }
        }
    }
}
